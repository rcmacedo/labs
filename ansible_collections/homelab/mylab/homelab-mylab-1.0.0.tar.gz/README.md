# Ansible Collection - homelab.mylab

Overview

The homelab.mylab collection provides Ansible playbooks and roles to quickly build and manage a homelab environment.
It automates provisioning of VMs, deployment of Ansible Automation Platform (AAP), and installation of OpenShift 4 for lab or testing purposes.

Installation



